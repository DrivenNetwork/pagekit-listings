<h2 class="uk-margin-remove">{{ 'About Listings' | trans }}</h2>
<h3>Version 1.0.4</h3>
<div>Created by <a href="https://driven.network" title="Driven Network" target="_driven">Driven Network, LLC</a></div>
<div>Email: <a href="mailto:contact@driven.network" title="Contact Email" target="_driven">contact@driven.network</a></div>
<div>Github: <a href="https://github.com/DrivenNetwork/pagekit-listings" title="Pagekit Listings on GitHub" target="_driven">pagekit-listings</a>
</div>
<div>Changelog: <a href="https://github.com/DrivenNetwork/pagekit-listings/blob/master/CHANGELOG.md" target="_driven" title="Pagekit Listings Changelog on GitHub">CHANGELOG.md</a>
</div>
